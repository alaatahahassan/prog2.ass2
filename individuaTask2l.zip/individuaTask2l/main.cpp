#include <cstdlib>
#include <bits/stdc++.h>
#include <iostream>
#include <string>
#include <valarray>
using namespace std;
void error (string message);


class Stack
{
private:
    enum { Max = 20 };
    valarray <char> data[Max] ;
    int  Size;

public:
    Stack ()
    {
        Size = 0;
    }

    bool isEmpty ()
    {
        if (Size == 0 )//&&  data[0].Size() == 0)
            return true;
        else
            return false;
    }

    void Clear ()
    {
        Size = 0;
        for (int i =0 ; i < Max ; i++)
            data[i].resize(0);
        cout<<"Done !! "<<endl<< "The Stack is clear now "<<endl;

    }
    int getSize()
    {

       return Size;
    }
    char pop()
    {
        if (Size == 0)
            error("Stack Underflow");
        char t = data[Size--][0];
        return t;
    }

    void push(char v)
    {
        if (Size == Max)
            error("Stack Overflow");
        data[ ++Size ] = std :: valarray<char> (v,1);

    }
};
void error (string message)
{
    cout << "\n" << message << "\n";
    exit (1);
}

int main ()
{
    Stack stack;
    stack.push ('a');
    stack.push ('b');
    stack.push ('c');
    stack.push ('r');
    cout << stack.getSize() <<endl;
    //stack.Clear();
    cout<<stack.isEmpty()<<endl;
    cout << stack.pop() << " ";
    cout << stack.pop() << " ";
    cout << stack.pop() << " ";
    cout << stack.pop() << " ";

}
